package pens.lab.app.belajaractivity.base;

public interface FragmentListener {
    void setTitle(String title);
}
